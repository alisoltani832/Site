import React from 'react'

export default function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>سلام! این سایت نمونه علی سلطانی است 🚀</h1>
      <p>ساخته شده با React + Vite + Vercel</p>
    </div>
  )
}
